<?php

header('Content-type: text/html; charset=utf-8');
$connect = new mysqli('localhost', 'root', '', 'prakt1');

if ($connect->connect_error) {
    die('Error : ('. $connect->connect_errno .') '. $connect->connect_error);
}
$connect->set_charset('utf8');	
var_dump(mysqli_error($connect));
