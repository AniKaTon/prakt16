<?php
require_once "function.php";

$mas = array();
$mas[1] = check('name', 'Имя', "/[A-Za-zА-Яа-яЁё0-9]{2,13}/u"); 
$mas[2] = check('surname', 'Фамилия', "/[A-Za-zА-Яа-яЁё]{2,16}/u");	
$mas[3] = check('patronymic', 'Отчество', "/[A-Za-zА-Яа-яЁё]{4,16}/u");
$mas[4] = check('email', 'email', "/[@]/u");
$mas[5] = check('password', 'Пароль', "/(?=.*\d{1})(?=.*[A-Z]{2,})(?=.*\W{3}).{6,12}/u");
$mas[6] = check('login', 'Логин', "/.{4,}/u");
