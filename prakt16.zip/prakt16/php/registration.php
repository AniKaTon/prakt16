<?php 	
include_once "../engine/connect.php";
include_once "../engine/function.php";

#var_dump($_POST);

if (isset($_POST['submit'])) 
{
	include_once "../engine/array.php";
	
	$list = $_POST['list'];

	foreach ($_POST['kurs'] as $key => $value)
			{
				$radio = $value;
			}
		echo '<br>Вы зарегистрированы с данными:' . '<br>Имя: ' . $mas[1] . '<br>Фамилия: ' . $mas[2] 
			. '<br>Отчество: ' .  $mas[3] . '<br>Почта: ' . $mas[4] . '<br>Пароль: ' . $mas[5]
			. '<br>Логин: ' . $mas[6] . '<br>Учебное заведение: ' . $list . '<br>Курс: ' . $radio; 

	$connect->query("INSERT INTO `user` (`name`, `surname`, `patronymic`, `email`, `password`, `login`, `college`,
	 `kurs`) VALUES ('$mas[1]', '$mas[2]', '$mas[3]', '$mas[4]', '$mas[5]', '$mas[6]', '$list', '$radio'); ");	
}

$connect->close();