<?php
include_once "../engine/connect.php";
include_once "../engine/function.php";

$login = $_POST['login'];
$query = $connect->query(" SELECT * FROM `user` WHERE `login` = '$login';");
$row = $query->fetch_assoc();
$check = $row['kurs'];
$college = $row['college'];


if (isset($_POST['kurs']))
{
	foreach ($_POST['kurs'] as $value)
		$radio = $value;
}



if (isset($_POST['subm'])) {

	$connect->query("UPDATE user SET name 	= '" . $_POST['name'] 	 	. "',
							surname 		= '" . $_POST['surname'] 	. "',
							email 			= '" . $_POST['email'] 	 	. "',
							password 		= '" . $_POST['password']	. "',
							college 		= '" . $_POST['list'] 	 	. "',
							kurs 			= '" . $radio 	 	. "'	
							WHERE login = '" . $_POST['login'] . "' ");
	echo "Изменения приняты";
} 



$connect->close();	